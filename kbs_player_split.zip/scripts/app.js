
document.addEventListener('DOMContentLoaded', () => {
    // 즉시 실행 함수 (IIFE)로 전체 코드를 감싸 전역 스코프 오염 방지
    (function() {
        // --- 요소 정의 ---
        const getElem = (id) => document.getElementById(id);
        const video = getElem('videoPlayer');
        const playerContainer = getElem('playerContainer');
        // const overlayPlayPauseBtn = getElem('overlayPlayPauseBtn'); // 제거
        const controlsPlayPauseBtn = getElem('controlsPlayPauseBtn');
        const playPauseIcon = getElem('playPauseIcon');
        const progressBar = getElem('progressBar');
        const volumeSlider = getElem('volumeSlider');
        const volumeIcon = getElem('volumeIcon');
        const speedSelect = getElem('speedSelect');
        const fitSelect = getElem('fitSelect');
        const pipBtn = getElem('pipBtn');
        const miniPlayerBtn = getElem('miniPlayerBtn');
        const fullscreenBtn = getElem('fullscreenBtn');
        const fullscreenIcon = fullscreenBtn.querySelector('i');
        const feedbackBox = getElem('feedbackBox');
        const currentTimeSpan = getElem('currentTime');
        const durationSpan = getElem('duration');
        const channelSelect = getElem('channelSelect');
        const currentChannelNameSpan = getElem('currentChannelName');
        // const overlay = getElem('overlay'); // 제거
        const searchInput = getElem('searchInput');
        const searchBtn = getElem('searchBtn');
        const spinner = getElem('spinner');
        const loadingText = getElem('loadingText');
        const adTimeDisplay = getElem('adTimeDisplay');
        const skipSlideOverlay = getElem('skipSlideOverlay'); // Add this line
        const bookmarkBtn = getElem('bookmarkBtn');
        const progressBarContainer = document.querySelector('.progress-bar-container');
        const progressTooltip = getElem('progressTooltip');
        const chaptersBtn = getElem('chaptersBtn');
        const chapterListPopup = getElem('chapterListPopup');
        const chapterListUl = getElem('chapterListUl');
        const recentChannelBtn = getElem('recentChannelBtn');
        const recentChannelPopup = getElem('recentChannelPopup');
        const recentChannelUl = getElem('recentChannelUl');
        const controls = getElem('controls');

        // --- 설정 및 상태 변수 ---
        const config = {
            adVideoSrc: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
            slideThreshold: -80, // Threshold for ad skip slide (pixels to the left)
            chapters: [
                { time: 0, title: "오프닝" }, { time: 60, title: "챕터 1: 시작" },
                { time: 180, title: "챕터 2: 위기" }, { time: 300, title: "챕터 3: 절정" },
                { time: 520, title: "엔딩 크레딧" }
            ],
            channelStreams: {
                'KBS1': { playlist: [{ title: '엘리펀츠 드림', src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4' }] },
                'KBS2': { playlist: [{ title: '신텔', src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4' }] },
                'KBSNEWS': { playlist: [{ title: 'For Bigger Blazes', src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' }] },
                'KBSSPORTS': { playlist: [{ title: 'Tears of Steel', src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4' }] }
            }
        };

        let state = {
            isAdPlaying: true,
            isDraggingProgress: false,
            bookmarks: JSON.parse(localStorage.getItem('videoBookmarks')) || {},
            currentPlaylist: [],
            currentPlaylistIndex: -1,
            videoPlaybackPosition: JSON.parse(localStorage.getItem('videoPlaybackPosition')) || {},
            hideControlsTimeout: null,
            feedbackTimeout: null,
            isMiniPlayerDragging: false,
            miniPlayerOffsetX: 0,
            miniPlayerOffsetY: 0,
            isAdSkipDragging: false,
            adSkipStartX: 0,
        };

        // --- 유틸리티 함수 ---
        const formatTime = (seconds) => {
            if (isNaN(seconds) || seconds < 0) return "00:00";
            const date = new Date(seconds * 1000);
            const hh = date.getUTCHours();
            const mm = date.getUTCMinutes();
            const ss = date.getUTCSeconds().toString().padStart(2, '0');
            return hh > 0 ? `${hh}:${mm.toString().padStart(2, '0')}:${ss}` : `${mm.toString().padStart(2, '0')}:${ss}`;
        };

        const showFeedback = (message) => {
            feedbackBox.textContent = message;
            feedbackBox.classList.add('show');
            clearTimeout(state.feedbackTimeout);
            state.feedbackTimeout = setTimeout(() => {
                feedbackBox.classList.remove('show');
            }, 1500);
        };

        const showLoading = (isLoading) => {
            spinner.style.display = isLoading ? 'block' : 'none';
            loadingText.style.display = isLoading ? 'block' : 'none';
        };

        // --- 플레이어 컨트롤 함수 ---
        const playVideo = () => {
            video.play().catch(error => {
                console.warn("자동 재생이 차단되었습니다:", error);
                updatePlayPauseIcon(true);
                // overlay.style.display = 'flex'; // 제거
            });
        };

        const togglePlayPause = () => {
            video.paused ? playVideo() : video.pause();
        };
        
        const updatePlayPauseIcon = (forcePause = false) => {
            const paused = video.paused || forcePause;
            playPauseIcon.className = `fas ${paused ? 'fa-play' : 'fa-pause'}`;
            const label = paused ? '재생' : '일시정지';
            // overlayPlayPauseBtn.setAttribute('aria-label', label); // 제거
            controlsPlayPauseBtn.setAttribute('aria-label', label);
        };
        
        const updateVolumeIcon = () => {
            if (video.muted || video.volume === 0) {
                volumeIcon.className = 'fas fa-volume-mute';
            } else if (video.volume < 0.5) {
                volumeIcon.className = 'fas fa-volume-down';
            } else {
                volumeIcon.className = 'fas fa-volume-up';
            }
        };

        const changeChannel = (channelValue) => {
            const selectedChannel = channelValue || channelSelect.value;
            const selectedOption = Array.from(channelSelect.options).find(opt => opt.value === selectedChannel);
            const selectedChannelName = selectedOption ? selectedOption.text : '';

            channelSelect.value = selectedChannel;
            currentChannelNameSpan.textContent = selectedChannelName;
            
            showLoading(true);
            video.pause();

            state.currentPlaylist = [];
            state.currentPlaylistIndex = -1;
            state.isAdPlaying = true;
            updateAdControls(true);

            video.src = config.adVideoSrc;
            video.load();
            playVideo();
            
            saveRecentChannel(selectedChannelName, selectedChannel);
            showFeedback(`채널 전환: ${selectedChannelName}`); // 채널 전환 피드백 추가
        };

        // 채널 인덱스를 통해 채널을 변경하는 함수 추가
        const changeChannelByIndex = (offset) => {
            const options = Array.from(channelSelect.options);
            let currentIndex = options.findIndex(option => option.value === channelSelect.value);
            let newIndex = currentIndex + offset;

            if (newIndex >= options.length) {
                newIndex = 0; // 마지막 채널에서 위로 이동하면 첫 채널로
            } else if (newIndex < 0) {
                newIndex = options.length - 1; // 첫 채널에서 아래로 이동하면 마지막 채널로
            }
            changeChannel(options[newIndex].value);
        };
        
        const playMainVideo = () => {
            if (!state.isAdPlaying) return;

            state.isAdPlaying = false;
            updateAdControls(false);

            const selectedChannelData = config.channelStreams[channelSelect.value] || {};
            state.currentPlaylist = selectedChannelData.playlist || [];
            
            let nextVideoSrc;
            if (state.currentPlaylist.length > 0) {
                state.currentPlaylistIndex = 0;
                nextVideoSrc = state.currentPlaylist[0].src;
                showFeedback(`재생 목록 시작: ${state.currentPlaylist[0].title}`);
            } else {
                showFeedback("광고가 종료되었습니다.");
                // 재생 목록이 없는 경우에 대한 대체 비디오가 필요하다면 여기에 추가
                nextVideoSrc = 'about:blank'; // 예: 빈 페이지
            }

            video.src = nextVideoSrc;
            video.load();
            playVideo();
        };

        const updateAdControls = (isAd) => {
            progressBar.disabled = isAd;
            speedSelect.disabled = isAd;
            chaptersBtn.disabled = isAd;
            bookmarkBtn.disabled = isAd;
            skipSlideOverlay.style.opacity = isAd ? '1' : '0'; // Control visibility
            skipSlideOverlay.style.pointerEvents = isAd ? 'auto' : 'none'; // Control interactivity
            adTimeDisplay.style.display = isAd ? 'block' : 'none';
        };

        // --- UI/마커 렌더링 함수 ---
        const drawMarkers = () => {
            // 기존 마커 모두 제거
            progressBarContainer.querySelectorAll('.bookmark-dot, .chapter-marker').forEach(m => m.remove());
            if (video.duration <= 0) return;

            // 북마크 그리기
            const currentBookmarks = state.bookmarks[video.src] || [];
            currentBookmarks.forEach(time => {
                const marker = document.createElement('div');
                marker.className = 'bookmark-dot';
                marker.style.left = `${(time / video.duration) * 100}%`;
                progressBarContainer.appendChild(marker);
            });

            // 챕터 그리기
            config.chapters.forEach(chapter => {
                const marker = document.createElement('div');
                marker.className = 'chapter-marker';
                marker.style.left = `${(chapter.time / video.duration) * 100}%`;
                marker.innerHTML = `<div class="chapter-tooltip">${chapter.title}</div>`;
                marker.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (!state.isAdPlaying) video.currentTime = chapter.time;
                });
                progressBarContainer.appendChild(marker);
            });
        };
        
        const populateChapterList = () => {
            chapterListUl.innerHTML = '';
            if (config.chapters.length === 0) {
                chaptersBtn.style.display = 'none';
            } else {
                chaptersBtn.style.display = 'inline-block';
                config.chapters.forEach(chapter => {
                    const li = document.createElement('li');
                    li.innerHTML = `<button><span>${formatTime(chapter.time)}</span>${chapter.title}</button>`;
                    li.querySelector('button').addEventListener('click', () => {
                        if (!state.isAdPlaying) {
                            video.currentTime = chapter.time;
                            chapterListPopup.classList.remove('show');
                        }
                    });
                    chapterListUl.appendChild(li);
                });
            }
        };

        // --- 로컬 스토리지 & 데이터 관리 ---
        const savePlaybackPosition = () => {
            if (video.src && video.duration > 0 && !video.paused && !state.isAdPlaying) {
                state.videoPlaybackPosition[video.src] = video.currentTime;
                localStorage.setItem('videoPlaybackPosition', JSON.stringify(state.videoPlaybackPosition));
            }
        };
        
        const loadPlaybackPosition = () => {
            const savedTime = state.videoPlaybackPosition[video.src];
            if (savedTime && savedTime > 0 && savedTime < video.duration) {
                video.currentTime = savedTime;
                showFeedback(`이어서 재생: ${formatTime(savedTime)}`);
            }
        };

        const saveBookmarks = () => {
            localStorage.setItem('videoBookmarks', JSON.stringify(state.bookmarks));
            drawMarkers();
        };
        
        const saveRecentChannel = (name, value) => {
            let recent = JSON.parse(localStorage.getItem('recentChannels')) || [];
            recent = recent.filter(c => c.value !== value);
            recent.unshift({ name, value, timestamp: Date.now() });
            localStorage.setItem('recentChannels', JSON.stringify(recent.slice(0, 5)));
        };

        const loadRecentChannels = () => {
            const recent = JSON.parse(localStorage.getItem('recentChannels')) || [];
            recentChannelUl.innerHTML = '';
            if (recent.length === 0) {
                recentChannelUl.innerHTML = '<li><button disabled style="color:#aaa; cursor:default;">최근 본 채널 없음</button></li>';
            } else {
                recent.forEach(c => {
                    const li = document.createElement('li');
                    const button = document.createElement('button');
                    button.textContent = c.name;
                    button.onclick = () => {
                        changeChannel(c.value);
                        recentChannelPopup.classList.remove('show');
                    };
                    li.appendChild(button);
                    recentChannelUl.appendChild(li);
                });
            }
        };

        // --- 이벤트 핸들러 ---
        const handleVideoEvents = () => {
            video.addEventListener('play', () => {
                updatePlayPauseIcon();
                // overlay.style.display = 'none'; // 제거
                clearTimeout(state.hideControlsTimeout);
                state.hideControlsTimeout = setTimeout(() => controls.classList.remove('show'), 3000);
            });

            video.addEventListener('pause', () => {
                updatePlayPauseIcon();
                // overlay.style.display = 'flex'; // 제거
                clearTimeout(state.hideControlsTimeout);
                controls.classList.add('show');
            });

            video.addEventListener('loadedmetadata', () => {
                durationSpan.textContent = formatTime(video.duration);
                showLoading(false);
                drawMarkers();
                populateChapterList();
                loadPlaybackPosition();
            });

            video.addEventListener('timeupdate', () => {
                if (!state.isDraggingProgress) {
                    progressBar.value = video.duration ? (video.currentTime / video.duration) * 100 : 0;
                }
                currentTimeSpan.textContent = formatTime(video.currentTime);

                if (state.isAdPlaying) {
                    const remaining = video.duration - video.currentTime;
                    adTimeDisplay.textContent = `광고 ${formatTime(remaining)}초 후 종료`;
                } else {
                    savePlaybackPosition();
                }
            });

            video.addEventListener('ended', () => {
                if (state.isAdPlaying) {
                    playMainVideo();
                } else if (state.currentPlaylist.length > 0 && state.currentPlaylistIndex < state.currentPlaylist.length - 1) {
                    state.currentPlaylistIndex++;
                    const nextVideo = state.currentPlaylist[state.currentPlaylistIndex];
                    video.src = nextVideo.src;
                    video.load();
                    playVideo();
                    showFeedback(`다음 영상: ${nextVideo.title}`);
                } else {
                    updatePlayPauseIcon(true);
                    showFeedback("재생 목록 종료");
                }
            });

            video.addEventListener('click', togglePlayPause); // 비디오 화면 클릭 시 재생/일시정지
        };

        const handleControlEvents = () => {
            // overlayPlayPauseBtn.addEventListener('click', togglePlayPause); // 제거
            controlsPlayPauseBtn.addEventListener('click', togglePlayPause);
            
            progressBar.addEventListener('input', () => {
                if(state.isAdPlaying) return;
                const seekTime = (progressBar.value / 100) * video.duration;
                currentTimeSpan.textContent = formatTime(seekTime); // 즉시 시간 피드백
            });
            progressBar.addEventListener('change', () => {
                if(state.isAdPlaying) return;
                video.currentTime = (progressBar.value / 100) * video.duration;
                state.isDraggingProgress = false;
            });
            progressBar.addEventListener('mousedown', () => {
                if(state.isAdPlaying) return;
                state.isDraggingProgress = true;
            });
            progressBar.addEventListener('mouseup', () => {
                if(state.isAdPlaying) return;
                state.isDraggingProgress = false;
            });
            progressBarContainer.addEventListener('mousemove', (e) => {
                if (!video.duration) return;
                const rect = progressBar.getBoundingClientRect();
                const pos = (e.clientX - rect.left) / rect.width;
                const time = formatTime(pos * video.duration);
                progressTooltip.style.left = `${e.clientX - progressBarContainer.getBoundingClientRect().left}px`;
                progressTooltip.textContent = time;
                progressTooltip.style.display = 'block';
            });
            progressBarContainer.addEventListener('mouseleave', () => {
                progressTooltip.style.display = 'none';
            });

            volumeSlider.addEventListener('input', () => {
                video.muted = false;
                video.volume = volumeSlider.value;
                updateVolumeIcon();
                showFeedback(`볼륨: ${Math.round(video.volume * 100)}%`);
            });
            
            volumeIcon.addEventListener('click', () => {
                video.muted = !video.muted;
                volumeSlider.value = video.muted ? 0 : video.volume;
                updateVolumeIcon();
                showFeedback(video.muted ? "음소거" : "음소거 해제");
            });

            speedSelect.addEventListener('change', () => video.playbackRate = parseFloat(speedSelect.value));
            fitSelect.addEventListener('change', () => video.style.objectFit = fitSelect.value);
            pipBtn.addEventListener('click', () => video.requestPictureInPicture().catch(e => showFeedback("PIP 모드 실패")));
            
            miniPlayerBtn.addEventListener('click', () => {
                playerContainer.classList.toggle('mini-player');
                showFeedback(playerContainer.classList.contains('mini-player') ? "미니 플레이어" : "일반 플레이어");
            });

            fullscreenBtn.addEventListener('click', () => {
                document.fullscreenElement ? document.exitFullscreen() : playerContainer.requestFullscreen();
            });

            document.addEventListener('fullscreenchange', () => {
                const isFullscreen = !!document.fullscreenElement;
                fullscreenIcon.className = `fas ${isFullscreen ? 'fa-compress' : 'fa-expand'}`;
            });

            channelSelect.addEventListener('change', () => changeChannel());
            
            bookmarkBtn.addEventListener('click', () => {
                if(state.isAdPlaying) return;
                const videoSrc = video.src;
                if (!state.bookmarks[videoSrc]) state.bookmarks[videoSrc] = [];
                
                const currentTime = video.currentTime;
                const existingIndex = state.bookmarks[videoSrc].findIndex(b => Math.abs(b - currentTime) < 1);
                
                if (existingIndex > -1) {
                    state.bookmarks[videoSrc].splice(existingIndex, 1);
                    showFeedback(`북마크 제거: ${formatTime(currentTime)}`);
                } else {
                    state.bookmarks[videoSrc].push(currentTime);
                    state.bookmarks[videoSrc].sort((a, b) => a - b);
                    showFeedback(`북마크 추가: ${formatTime(currentTime)}`);
                }
                saveBookmarks();
            });

            chaptersBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                chapterListPopup.classList.toggle('show');
            });
            
            recentChannelBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                loadRecentChannels();
                const btnRect = recentChannelBtn.getBoundingClientRect();
                recentChannelPopup.style.top = `${btnRect.bottom + 5}px`;
                recentChannelPopup.style.left = `${btnRect.left}px`;
                recentChannelPopup.classList.toggle('show');
            });
            
            searchBtn.addEventListener('click', () => {
                const query = searchInput.value.trim();
                if (query) {
                    showFeedback(`'${query}' 검색 (미구현)`);
                    // 실제 검색 로직 구현 위치
                }
            });
            searchInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') searchBtn.click();
            });
        };
        
        const handleGlobalEvents = () => {
            document.addEventListener('click', (e) => {
                if (!chapterListPopup.contains(e.target) && e.target !== chaptersBtn) {
                    chapterListPopup.classList.remove('show');
                }
                if (!recentChannelPopup.contains(e.target) && e.target !== recentChannelBtn) {
                    recentChannelPopup.classList.remove('show');
                }
            });

            document.addEventListener('keydown', (e) => {
                // 입력 필드가 포커스된 경우 키보드 이벤트 무시
                if (e.target.tagName === 'INPUT' || e.ctrlKey || e.altKey || e.metaKey) return;

                const keyMap = {
                    ' ': () => { e.preventDefault(); togglePlayPause(); },
                    'k': togglePlayPause,
                    // 'ArrowRight': () => { if(!state.isAdPlaying) video.currentTime += 5; }, // 제거
                    // 'ArrowLeft': () => { if(!state.isAdPlaying) video.currentTime -= 5; }, // 제거
                    'ArrowUp': () => { e.preventDefault(); changeChannelByIndex(1); }, // 채널 위로 (다음 채널)
                    'ArrowDown': () => { e.preventDefault(); changeChannelByIndex(-1); }, // 채널 아래로 (이전 채널)
                    'm': () => volumeIcon.click(),
                    'f': () => fullscreenBtn.click(),
                    'p': () => pipBtn.click()
                };
                
                if(keyMap[e.key]) keyMap[e.key]();
            });

            playerContainer.addEventListener('mousemove', () => {
                controls.classList.add('show');
                clearTimeout(state.hideControlsTimeout);
                if (!video.paused) {
                    state.hideControlsTimeout = setTimeout(() => controls.classList.remove('show'), 3000);
                }
            });
            playerContainer.addEventListener('mouseleave', () => {
                if (!video.paused) {
                    controls.classList.remove('show');
                }
            });
        };
        
        const handleDragEvents = () => {
            // Mini-player drag
            const handleMiniPlayerDragStart = (e) => {
                if (!playerContainer.classList.contains('mini-player')) return;
                state.isMiniPlayerDragging = true;
                playerContainer.style.cursor = 'grabbing';
                const clientX = e.clientX || e.touches[0].clientX;
                const clientY = e.clientY || e.touches[0].clientY;
                state.miniPlayerOffsetX = clientX - playerContainer.offsetLeft;
                state.miniPlayerOffsetY = clientY - playerContainer.offsetTop;
            };

            const handleMiniPlayerDragMove = (e) => {
                if (!state.isMiniPlayerDragging) return;
                e.preventDefault();
                const clientX = e.clientX || e.touches[0].clientX;
                const clientY = e.clientY || e.touches[0].clientY;
                let newX = clientX - state.miniPlayerOffsetX;
                let newY = clientY - state.miniPlayerOffsetY;

                // 화면 밖으로 나가지 않도록 제한
                const max_X = window.innerWidth - playerContainer.offsetWidth;
                const max_Y = window.innerHeight - playerContainer.offsetHeight;
                newX = Math.max(0, Math.min(newX, max_X));
                newY = Math.max(0, Math.min(newY, max_Y));

                playerContainer.style.right = 'auto'; // 기존 right 속성 제거
                playerContainer.style.bottom = 'auto'; // 기존 bottom 속성 제거
                playerContainer.style.left = `${newX}px`;
                playerContainer.style.top = `${newY}px`;
            };

            const handleMiniPlayerDragEnd = () => {
                if (!state.isMiniPlayerDragging) return;
                state.isMiniPlayerDragging = false;
                playerContainer.style.cursor = 'grab';
            };

            playerContainer.addEventListener('mousedown', handleMiniPlayerDragStart);
            document.addEventListener('mousemove', handleMiniPlayerDragMove);
            document.addEventListener('mouseup', handleMiniPlayerDragEnd);
            playerContainer.addEventListener('touchstart', handleMiniPlayerDragStart, { passive: false });
            document.addEventListener('touchmove', handleMiniPlayerDragMove, { passive: false });
            document.addEventListener('touchend', handleMiniPlayerDragEnd);

            // Ad skip slide drag (new implementation)
            const handleAdSkipDragStart = (e) => {
                if (!state.isAdPlaying) return;
                state.isAdSkipDragging = true;
                skipSlideOverlay.style.cursor = 'grabbing';
                state.adSkipStartX = (e.clientX || e.touches[0].clientX);
                skipSlideOverlay.style.transition = 'none'; // Disable transition during drag
            };

            const handleAdSkipDragMove = (e) => {
                if (!state.isAdSkipDragging || !state.isAdPlaying) return;
                e.preventDefault(); // Prevent text selection etc.
                const currentX = (e.clientX || e.touches[0].clientX);
                let deltaX = currentX - state.adSkipStartX;
                
                // Limit slide to the left (negative delta)
                deltaX = Math.min(0, deltaX);

                skipSlideOverlay.style.transform = `translate(-100%, -50%) translateX(${deltaX}px)`;

                // Optional: Provide visual feedback based on slide progress
                if (deltaX < config.slideThreshold) {
                    skipSlideOverlay.style.backgroundColor = 'rgba(255, 204, 0, 0.5)';
                    skipSlideOverlay.style.color = '#111';
                } else {
                    skipSlideOverlay.style.backgroundColor = 'rgba(255,255,255,0.15)';
                    skipSlideOverlay.style.color = '#fff';
                }
            };

            const handleAdSkipDragEnd = (e) => {
                if (!state.isAdSkipDragging || !state.isAdPlaying) return;
                state.isAdSkipDragging = false;
                skipSlideOverlay.style.cursor = 'grab';
                skipSlideOverlay.style.transition = 'all 0.1s ease-out'; // Re-enable transition

                const finalX = (e.clientX || e.changedTouches[0].clientX);
                const deltaX = finalX - state.adSkipStartX;

                if (deltaX <= config.slideThreshold) {
                    playMainVideo();
                    showFeedback("광고 건너뛰기");
                }
                // Reset position regardless of whether ad was skipped
                skipSlideOverlay.style.transform = 'translate(-100%, -50%)';
                skipSlideOverlay.style.backgroundColor = 'rgba(255,255,255,0.15)'; // Reset color
                skipSlideOverlay.style.color = '#fff'; // Reset text color
            };

            skipSlideOverlay.addEventListener('mousedown', handleAdSkipDragStart);
            document.addEventListener('mousemove', handleAdSkipDragMove);
            document.addEventListener('mouseup', handleAdSkipDragEnd);
            skipSlideOverlay.addEventListener('touchstart', handleAdSkipDragStart, { passive: false });
            document.addEventListener('touchmove', handleAdSkipDragMove, { passive: false });
            document.addEventListener('touchend', handleAdSkipDragEnd);
        };

        // --- 초기화 실행 ---
        function init() {
            handleVideoEvents();
            handleControlEvents();
            handleGlobalEvents();
            handleDragEvents(); // This now includes both mini-player and ad skip drag logic

            updateAdControls(true); // Ensure ad controls are set up initially
            updatePlayPauseIcon(true);
            updateVolumeIcon();
            loadRecentChannels();
            
            showLoading(true);
            video.src = config.adVideoSrc;
            video.load();
            playVideo();
        }

        init();
    })();
});
